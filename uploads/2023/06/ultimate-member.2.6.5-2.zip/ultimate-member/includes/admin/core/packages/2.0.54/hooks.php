<?php if ( ! defined( 'ABSPATH' ) ) exit;

return array(
	'roles2054' => 'roles2054',
);